# Python_Panda_for_Data_Science
A course with basics of Python and Pandas
